/*
 *
 * Author: Vemparala Raghu Sai Phani Sriraj
 * File Name: PWM.h
 * Use: This file contains all the function declarations required for pulse width modulation to function properly.
 * Compiler: GCC
 * References:1. DEAN text book Chapter:7
 *
 */

#ifndef PWM_H_
#define PWM_H_
#define RED_LED 18
#define GREEN_LED 19
#define BLUE_LED 1
#define CONVERSION_TO_PWM_RANGE 188
/* Function Name: PWM_init
 * Use: PWM_init function is used to initialize PWM.
 * Return Type: void
 */
void PWM_init();
/* Function Name: PWM_trigger
 * Use:Trigger PWM signal.
 * Return Type: void
 */
void PWM_trigger();
/* Function Name: transitioncolor_state
 * Use: Transition color change is performed in this function.
 * Return Type: void
 */
void colortransition();
#endif /* PWM_H_ */
