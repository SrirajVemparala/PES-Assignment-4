/*
 *
 * Author: Vemparala Raghu Sai Phani Sriraj
 * File Name: log.h
 * Use: This file has function to print the data into the console
 * Compiler: GCC
 *
 */
#include "stdio.h"
#ifndef LOG_H_
#define LOG_H_

#ifdef DEBUG
#define LOG PRINTF
#else
#define LOG(...)
#endif

#endif /* LOG_H_ */
