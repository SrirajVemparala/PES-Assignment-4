/*
 *
 * Author: Vemparala Raghu Sai Phani Sriraj
 * File Name: mainfile.c
 * Use: This file contains main function.
 * Compiler: GCC
 */
#include "header.h"
#include "log.h"
/* Function Name: main
 * Use: Contains initializations of all the modules and also calls state machine.
 * Returns 1 if touch sensor is pressed or Returns 0 if touch sensor is not pressed.
 * Return Type: int
 */

int main(void)
{
	LOG("MAIN STARTED");
	bool capacitivesensor_flag = 0;// Used to check if the touch sensor is touched
	BOARD_InitBootPins();
	BOARD_InitBootClocks();
	BOARD_InitBootPeripherals();
    init_systick();
    PWM_init();
    touch_init();
	while (1)
	{
		/* IF statement is used to poll capacitive sensor when interrupt is triggered*/
		if((1 == get_int_status()) && (1== touch_detection()))
		{
			capacitivesensor_flag = 1;
		}
		else
		{
			capacitivesensor_flag = 0;
		}
		statemachine(capacitivesensor_flag);//State Machine function call
	}

}


