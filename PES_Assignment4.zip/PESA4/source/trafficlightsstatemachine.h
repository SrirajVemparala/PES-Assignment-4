/*
 *
 * Author: Vemparala Raghu Sai Phani Sriraj
 * File Name: trafficlightsstatemachine.c
 * Use: This file contains all the function declarations and code required for state machine to function properly.
 * Compiler: GCC
 *
 */

#ifndef TRAFFICLIGHTSSTATEMACHINE_H_
#define TRAFFICLIGHTSSTATEMACHINE_H_

#define RED_INITIAL_STOP			(0x61) //RED value for STOP brightness frequency
#define GREEN_INITIAL_STOP		    (0x1E) //GREEN value for STOP brightness frequency
#define BLUE_INITIAL_STOP 			(0x3C) //BLUE value for STOP brightness frequency

#define RED_INITIAL_GO				(0x22)	//RED value for GO brightness frequency
#define GREEN_INITIAL_GO			(0x96)	//GREEN value for GO brightness frequency
#define BLUE_INITIAL_GO			    (0x22)	//BLUE value for GO brightness frequency

#define RED_INITIAL_WARNING 		(0xFF)	//RED value for WARNING brightness frequency
#define GREEN_INITIAL_WARNING 		(0xB2)	//GREEN value for WARNING brightness frequency
#define BLUE_INITIAL_WARNING 		(0x00)	//BLUE value for WARNING brightness frequency

#define RED_INITIAL_CROSSWALK		(0x00)	//RED value for CROSSWALK brightness frequency
#define GREEN_INITIAL_CROSSWALK		(0x10)	//GREEN value for CROSSWALK brightness frequency
#define BLUE_INITIAL_CROSSWALK		(0x30)	//BLUE value for CROSSWALK brightness frequency

#define DELAY_INITIAL_TRANSITION  	(100) 	//1 second
#ifdef DEBUG
#define DELAY_STOP_GO	(500)				//5 seconds
#define DELAY_WARNING 	(300)				//3 seconds
#else
#define DELAY_STOP_GO	(2000)				//20 seconds
#define DELAY_WARNING 	(500)				//5 seconds
#endif
#define DELAY_CROSSWALK (1000)				//10 second
#define DELAY_ONESEC	(100)				//1 second
#define DELAY_SIXTY_TWO_AND_HALF_MS (625/100) //62.5 milliseconds
void statemachine(bool);


#endif /* TRAFFICLIGHTSSTATEMACHINE_H_ */

typedef enum {
	        STOP,
			GO ,
			WARNING,
			CROSSWALK,
}state_t;

typedef uint32_t ticktime_t;
ticktime_t get_timer();
void transitiontocrosswalk(volatile uint8_t* ,state_t); //Used for transition to crosswalk
void transition(); //Used for transition from state to other state
