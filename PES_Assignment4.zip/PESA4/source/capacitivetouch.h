/*
 *
 * Author: Vemparala Raghu Sai Phani Sriraj
 * File Name: capacitivetouch.h
 * Use: This file contains all the function declarations required for touch sensor to function properly.
 * Compiler: GCC
 * References:1. https://github.com/alexander-g-dean/ESF/blob/master/NXP/Code/Chapter_2/Source/main.c
 * 			  2. https://github.com/alexander-g-dean/ESF/tree/master/NXP/Misc/Touch%20Sense.
 *
 */

#ifndef CAPACITIVETOUCH_H_
#define CAPACITIVETOUCH_H_

/* Function Name: touch_init
 * Use: touch_init function is used to initialize the capacitive sensor.
 * Return Type: void.
 */
void touch_init(void);
/* Function Name: touch_detection
 * Use: touch_detection function is used to detect whether the touch sensor is detected or not
 * Returns 1 if touch sensor is pressed or Returns 0 if touch sensor is not pressed.
 * Return Type: int
 */
int touch_detection(void);

#endif /* CAPACITIVETOUCH_H_ */
