/*
 *
 * Author: Vemparala Raghu Sai Phani Sriraj
 * File Name: trafficlightsstatemachine.c
 * Use: This file contains all the function definitions and code required for state machine to function properly.
 * Compiler: GCC
 *
 */

#include "header.h"
#include "log.h"
__IO uint8_t rgbcurrentintensity[3];
__IO uint8_t rgbinitialintensity[3];
__IO uint8_t rgbfinalintensity[3];
int DELAY_TWO_FIFTY_MS = 25;
int DELAY_SEVEN_FIFTY_MS = 75;
state_t state=STOP;
/* Function Name: delay
 * Use: delay function is used to provide delay for crosswalk LED blink.
 * Return Type: void.
 */
void delay(uint8_t delayvalue)
{
	int time_at_loop_start = get_timer();
	while((get_timer()-time_at_loop_start) <delayvalue)
	{

	}
}
/* Function Name: statemachine
 * Use: statemachine function is used to shift from one state to other state.
 * Return Type: void.
 * parameters:bool capacitivesensor_flag
 */
void statemachine(bool capacitivesensor_flag) {
	switch (state)
		{
		case STOP:
			if(get_timer() < DELAY_STOP_GO)
			{
				rgbcurrentintensity[0] = RED_INITIAL_STOP;
				rgbcurrentintensity[1] = GREEN_INITIAL_STOP;
				rgbcurrentintensity[2] = BLUE_INITIAL_STOP;
				PWM_trigger(rgbcurrentintensity);
				if(1 == capacitivesensor_flag)// Check if flag is set
				{
					transitiontocrosswalk(rgbcurrentintensity,state);//transaction to crosswalk if touch is sensed
					state = CROSSWALK;
					reset_timer();
					LOG("Button pressed inside STOP state and go to CROSSWALk state via transition\r\n");
					LOG("Time now into CROSSWALK from GO:%d\r\n",now()*10);
				}
			}
			else
			{
				state = STOP;// Remain in stop if Touch is not pressed
				transition();//Transition to GO State
				reset_timer();
				LOG("State transition from STOP TO GO\r\n");
				LOG("Time now for STOP TO GO state:%d\r\n",now()*10);
			}
			break;

		case GO:
			if(get_timer() < DELAY_STOP_GO)
			{
				rgbcurrentintensity[0] = RED_INITIAL_GO;
				rgbcurrentintensity[1] = GREEN_INITIAL_GO;
				rgbcurrentintensity[2] = BLUE_INITIAL_GO;
				PWM_trigger(rgbcurrentintensity);
				if(1 == capacitivesensor_flag)
				{
					transitiontocrosswalk(rgbcurrentintensity,state);
					state = CROSSWALK;
					reset_timer();
					LOG("Button pressed inside GO state and go to CROSSWALk state via transition\r\n");
					LOG("Time now into CROSSWALK FROM GO:%d\r\n",now()*10);
				}
			}
			else
			{
				state = GO;//current
				//reset_timer();
				transition();//Transition to Warning State
				reset_timer();
				LOG("State transition from GO TO WARNING\r\n");
				LOG("Time now for GO TO WARNING state:%d\r\n",now()*10);
			}
			break;

		case WARNING:
			if(get_timer() < DELAY_WARNING)
			{
				rgbcurrentintensity[0] = RED_INITIAL_WARNING;
				rgbcurrentintensity[1] = GREEN_INITIAL_WARNING;
				rgbcurrentintensity[2] = BLUE_INITIAL_WARNING;
				PWM_trigger(rgbcurrentintensity);
				if(1 == capacitivesensor_flag)
				{
					transitiontocrosswalk(rgbcurrentintensity,state);
					state = CROSSWALK;
					reset_timer();
					LOG("Button pressed inside WARNING state and go to CROSSWALk state via transition\r\n");
					LOG("Time now into CROSSWALK FROM WARNING:%d\r\n",now()*10);
				}
			}
			else
			{

				state = WARNING;//current
				transition();//Transition to STOP State
				reset_timer();
				LOG("State transition from WARNING TO STOP\r\n");
				LOG("Time now for WARNING TO STOP state:%d\r\n",now()*10);

			}
			break;
		case CROSSWALK:
	    	while(get_timer() < DELAY_CROSSWALK)
	    	{
	    		state = CROSSWALK;
				rgbcurrentintensity[0] = RED_INITIAL_CROSSWALK;
				rgbcurrentintensity[1] = GREEN_INITIAL_CROSSWALK;
				rgbcurrentintensity[2] = BLUE_INITIAL_CROSSWALK;
				PWM_trigger(rgbcurrentintensity);//Triggers CROSSWALK BLINK
		    	//printf("here1\n");
	    		delay(DELAY_SEVEN_FIFTY_MS);//750ms
	    		//printf("here2\n");
	    		rgbcurrentintensity[0] = 0x00;
	    		rgbcurrentintensity[1] = 0x00;
	    		rgbcurrentintensity[2] = 0x00;
	    		PWM_trigger(rgbcurrentintensity);
	    		delay(DELAY_TWO_FIFTY_MS);//250ms
	    	}
	    	transition();
	    	reset_timer();
			LOG("State transition from CROSSWALK TO GO\r\n");
			LOG("Time now for CROSSWALK TO GO state:%d\r\n",now()*10);
		  }
		}
/* Function Name: transition
 * Use: transition function is used to transit from one state to other state.
 * Return Type: void.
 *
 */
void transition()
{
			if (state == STOP)
			{
				if (get_timer() > (DELAY_INITIAL_TRANSITION))
				{
					state = GO;//Setting to next state
				}
				/*Setting the values of RGB to array for calculation*/
				rgbinitialintensity[0] = RED_INITIAL_STOP;
				rgbfinalintensity[0] = RED_INITIAL_GO;
				rgbinitialintensity[1] = GREEN_INITIAL_STOP;
				rgbfinalintensity[1] = GREEN_INITIAL_GO;
				rgbinitialintensity[2] = BLUE_INITIAL_STOP;
				rgbfinalintensity[2] = BLUE_INITIAL_GO;
				//Color change and 1 second transition happens inside the below function
				colortransition();
				LOG("Color transition from STOP to GO\r\n");
				LOG("Stop transition time now:%d\r\n",now()*10);

			}
			else if (state == GO)
			{
				if (get_timer() > DELAY_INITIAL_TRANSITION)
				{
					state = WARNING;//Setting to next state

				}
				/*Setting the values of RGB to array for calculation*/
				rgbinitialintensity[0] = RED_INITIAL_GO;
				rgbfinalintensity[0] = RED_INITIAL_WARNING;
				rgbinitialintensity[1] = GREEN_INITIAL_GO;
				rgbfinalintensity[1] = GREEN_INITIAL_WARNING;
				rgbinitialintensity[2] = BLUE_INITIAL_GO;
				rgbfinalintensity[2] = BLUE_INITIAL_WARNING;
				//Color change and 1 second transition happens inside the below function
				colortransition();
				LOG("Color transition from GO to WARNING\r\n");
				LOG("GO transition time now:%d\r\n",now()*10);
			}
			else if (state == WARNING)//state
			{
				if (get_timer() > DELAY_INITIAL_TRANSITION)
				{
					state = STOP;//Setting to next state

				}
				/*Setting the values of RGB to array for calculation*/
				rgbinitialintensity[0] = RED_INITIAL_WARNING;
				rgbfinalintensity[0] = RED_INITIAL_STOP;
				rgbinitialintensity[1] = GREEN_INITIAL_WARNING;
				rgbfinalintensity[1] = GREEN_INITIAL_STOP;
				rgbinitialintensity[2] = BLUE_INITIAL_WARNING;
				rgbfinalintensity[2] = BLUE_INITIAL_STOP;
				//Color change and 1 second transition happens inside the below function
				colortransition();
				LOG("Color transition from WARNING to STOP\r\n");
				LOG("WARNING transition time now:%d\r\n",now()*10);
			}
			else if(state == CROSSWALK)
			{
				if (get_timer() > DELAY_INITIAL_TRANSITION)
				{
					state = GO;
				}
				rgbinitialintensity[0] = RED_INITIAL_CROSSWALK;
				rgbfinalintensity[0] = RED_INITIAL_GO;
				rgbinitialintensity[1] = GREEN_INITIAL_CROSSWALK;
				rgbfinalintensity[1] = GREEN_INITIAL_GO;
				rgbinitialintensity[2] = BLUE_INITIAL_CROSSWALK;
				rgbfinalintensity[2] = BLUE_INITIAL_GO;
				//Color change and 1 second transition happens inside the below function
				colortransition();
				LOG("Color transition from CROSSWALK to GO\r\n");
				LOG("CROSSWALK transition time now:%d\r\n",now()*10);
			}
			else
			{
				/*Do Nothing*/
			}
}
/* Function Name: transitiontocrosswalk
 * Use: This function is used to transit from one state to CROSSWALK state.
 * Return Type: void.
 *Parameters: rgbcurrentintensity,statetransitionfrom
 */
void transitiontocrosswalk(volatile uint8_t* rgbcurrentintensity,state_t statetransitionfrom)
{
	if(statetransitionfrom == STOP)
	{
		//Setting initial values
		rgbinitialintensity[0] = rgbcurrentintensity[0];
		rgbinitialintensity[1] = rgbcurrentintensity[1];
		rgbinitialintensity[2] = rgbcurrentintensity[2];
		rgbfinalintensity[0] = RED_INITIAL_CROSSWALK;
		rgbfinalintensity[1] = GREEN_INITIAL_CROSSWALK;
		rgbfinalintensity[2] = BLUE_INITIAL_CROSSWALK;
		//Color change and 1 second transition happens inside the below function
		colortransition();
		LOG("Color transition from STOP To CROSSWALK \r\n");
		LOG("STOP To CROSSWALK  transition time now:%d\r\n",now()*10);
	}
	else if(statetransitionfrom == GO)
	{
		rgbinitialintensity[0] = rgbcurrentintensity[0];
		rgbinitialintensity[1] = rgbcurrentintensity[1];
		rgbinitialintensity[2] = rgbcurrentintensity[2];
		rgbfinalintensity[0] = RED_INITIAL_CROSSWALK;
		rgbfinalintensity[1] = GREEN_INITIAL_CROSSWALK;
		rgbfinalintensity[2] = BLUE_INITIAL_CROSSWALK;
		//Color change and 1 second transition happens inside the below function
		colortransition();
		LOG("Color transition from GO To CROSSWALK \r\n");
		LOG("GO To CROSSWALK  transition time now:%d\r\n",now()*10);
	}
	else if(statetransitionfrom == WARNING)
	{
		rgbinitialintensity[0] = rgbcurrentintensity[0];
		rgbinitialintensity[1] = rgbcurrentintensity[1];
		rgbinitialintensity[2] = rgbcurrentintensity[2];
		rgbfinalintensity[0] = RED_INITIAL_CROSSWALK;
		rgbfinalintensity[1] = GREEN_INITIAL_CROSSWALK;
		rgbfinalintensity[2] = BLUE_INITIAL_CROSSWALK;
		//Color change and 1 second transition happens inside the below function
		colortransition();
		LOG("Color transition from WARNING To CROSSWALK \r\n");
		LOG("WARNING To CROSSWALK  transition time now:%d\r\n",now()*10);
	}
	else
	{
		/*Do Nothing*/
	}
}
