/*
 *
 * Author: Vemparala Raghu Sai Phani Sriraj
 * File Name: capacitivetouch.c
 * Use: This file contains all the function definitions required for touch sensor to function properly.
 * Compiler: GCC
 * References:1. https://github.com/alexander-g-dean/ESF/blob/master/NXP/Code/Chapter_2/Source/main.c
 * 			  2. https://github.com/alexander-g-dean/ESF/tree/master/NXP/Misc/Touch%20Sense.
 *
 */


#include "header.h"
#define TOUCH_OFFSET 670                      //OFFSET FOR MY TOUCH SENSOR
#define TOUCH_DATA (TSI0->DATA & 0xFFFF)      //OBTAINS TOUCH DATA
#define  TOUCH_THRESHOLD 10 //Threshold value to be reached to detect the touch

/* Function Name: touch_detection
 * Use: touch_detection function is used to detect whether the touch sensor is detected or not
 * Returns 1 if touch sensor is pressed or Returns 0 if touch sensor is not pressed.
 * Return Type: int
 */
int touch_detection()
{
	int scan = 0;
	TSI0->DATA = TSI_DATA_TSICH(10u);
	TSI0->DATA |= TSI_DATA_SWTS_MASK;                     //software trigger to start the scan
	while (!(TSI0->GENCS & TSI_GENCS_EOSF_MASK ))         //waiting for the scan to complete 32 times
	scan = TOUCH_DATA;
	TSI0->GENCS |= TSI_GENCS_EOSF_MASK ;                  //writing one to clear the end of scan flag
	if(scan - TOUCH_OFFSET >TOUCH_THRESHOLD)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

/* Function Name: touch_init
 * Use: touch_init function is used to initialize the capacitive sensor.
 * Return Type: void.
 */

void touch_init()
{
	SIM->SCGC5 |= SIM_SCGC5_TSI_MASK; //enabling the clock

	TSI0->GENCS = TSI_GENCS_OUTRGF_MASK | TSI_GENCS_MODE(0u) |
								TSI_GENCS_REFCHRG(0u) |
								TSI_GENCS_DVOLT(0u) |
								TSI_GENCS_EXTCHRG(0u) |
								TSI_GENCS_PS(0u) |      //frequency clock divided by one
								TSI_GENCS_NSCN(31u) |   //scanning the electrode 32 times
								TSI_GENCS_TSIEN_MASK |  //enabling the Touch Sensor
								TSI_GENCS_EOSF_MASK;    //writing one to clear the end of scan flag
}

