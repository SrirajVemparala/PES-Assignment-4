/*
 *
 * Author: Vemparala Raghu Sai Phani Sriraj
 * File Name: header.h
 * Use: This file contains all the header files required for the functions to work.
 * Compiler: GCC
 *
 *
 */

#ifndef HEADER_H_
#define HEADER_H_

#include <MKL25Z4.H>
#include "stdio.h"
#include <stdbool.h>
#include "stdint.h"
#include "board.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "peripherals.h"
#include "fsl_debug_console.h"
#include "core_cm0plus.h"
#include "trafficlightsstatemachine.h"
#include "PWM.h"
#include "Systick.h"
#include "capacitivetouch.h"
#include "core_cm0plus.h"


#endif /* HEADER_H_ */
